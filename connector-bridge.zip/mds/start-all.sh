#!/bin/sh

echo "Starting Connector Bridge..."
./runConnectorBridge.sh
